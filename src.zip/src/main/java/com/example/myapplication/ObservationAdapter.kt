package com.example.myapplication

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ObservationAdapter(
    private val observations: List<SavedObservation>,
    private val onDistanceClick: (SavedObservation) -> Unit,
    private val onItemClick: (SavedObservation) -> Unit
) : RecyclerView.Adapter<ObservationAdapter.ViewHolder>() {

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val titleTextView: TextView = view.findViewById(R.id.observationTitleText)
        val locationTextView: TextView = view.findViewById(R.id.observationLocationText)
        val distanceButton: Button = view.findViewById(R.id.distanceTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.observation_list_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val observation = observations[position]
        holder.titleTextView.text = observation.name
        holder.locationTextView.text = observation.birdSpecies
        holder.distanceButton.text = observation.distance

        // Handle distance button click
        holder.distanceButton.setOnClickListener {
            onDistanceClick(observation)
        }

        // Handle item click (entire item)
        holder.itemView.setOnClickListener {
            onItemClick(observation)
        }
    }

    override fun getItemCount() = observations.size
}
