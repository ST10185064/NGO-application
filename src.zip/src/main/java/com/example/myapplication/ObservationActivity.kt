package com.example.myapplication

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.myapplication.databinding.ActivityObservationBinding
import com.google.android.gms.maps.model.LatLng
import java.text.SimpleDateFormat
import java.util.*


class ObservationActivity : AppCompatActivity() {

    private lateinit var binding: ActivityObservationBinding
    private lateinit var capturedImageView: ImageView
    private lateinit var birdNameEditText: EditText
    private lateinit var birdSpeciesEditText: EditText
    private lateinit var observationDetailsEditText: EditText

    private val REQUEST_IMAGE_CAPTURE = 1
    private val REQUEST_CAMERA_PERMISSION = 200


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityObservationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Retrieve the hotspot name from the Intent
        val hotspotName = intent.getStringExtra("HOTSPOT_NAME") ?: "Unknown Hotspot"

        binding.hotspotNameTextView.text = "Hotspot: $hotspotName"

        // Initialize the ImageView for displaying the captured image
        capturedImageView = findViewById(R.id.captured_image_view)

        // Initialize the text fields for bird observation details
        birdNameEditText = findViewById(R.id.bird_name_edit_text)
        birdSpeciesEditText = findViewById(R.id.bird_species_edit_text)
        observationDetailsEditText = findViewById(R.id.observation_details_edit_text)

        // Set up the camera button
        val openCameraButton: Button = findViewById(R.id.open_camera_button)
        openCameraButton.setOnClickListener {
            checkCameraPermissionAndOpenCamera()
        }

        // Set up the save button to handle saving the observation
        val saveObservationButton: Button = findViewById(R.id.save_observation_button)
        saveObservationButton.setOnClickListener {
            saveObservation()
        }
    }

    private fun checkCameraPermissionAndOpenCamera() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // Request camera permission if it's not granted
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), REQUEST_CAMERA_PERMISSION)
        } else {
            // If permission is granted, open the camera
            openCamera()
        }
    }

    // Handle permission request result
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera() // Permission granted, open the camera
            } else {
                Toast.makeText(this, "Camera permission is required", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openCamera() {
        // Create an Intent to open the camera
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        if (takePictureIntent.resolveActivity(packageManager) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE)
        } else {
            Toast.makeText(this, "No camera app available", Toast.LENGTH_SHORT).show()
        }
    }

    // Handle the image capture result
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            val imageBitmap = data?.extras?.get("data") as Bitmap
            capturedImageView.setImageBitmap(imageBitmap) // Display the captured image
        } else {
            Toast.makeText(this, "Failed to capture image", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveObservation() {
        val birdName = birdNameEditText.text.toString()
        val birdSpecies = birdSpeciesEditText.text.toString()
        val observationDetails = observationDetailsEditText.text.toString()

        if (birdName.isEmpty() || birdSpecies.isEmpty() || observationDetails.isEmpty()) {
            Toast.makeText(this, "Please fill out all fields", Toast.LENGTH_SHORT).show()
            return
        }

        // Save observation details (you can modify this to save to a database)
        val distance = intent.getStringExtra("DISTANCE") ?: "0 kM"
        Toast.makeText(
            this,
            "Observation saved:\nDistance: $distance \nBird Name: $birdName\nSpecies: $birdSpecies\nDetails: $observationDetails",
            Toast.LENGTH_LONG
        ).show()

        fun getCurrentDate(): String {
            // Get an instance of Calendar
            val calendar = Calendar.getInstance()

            // Define the date format
            val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())

            // Format the date
            return dateFormat.format(calendar.time)
        }

        val todaytime:String = getCurrentDate();
        val hotspotName = intent.getStringExtra("HOTSPOT_NAME") ?: "Unknown Hotspot"

        val savedObservation = SavedObservation(birdName, birdSpecies, hotspotName ,todaytime,observationDetails)

        val intent = Intent(this, ObservationListActivity::class.java).apply {
            putExtra("SAVED_OBSERVATION", savedObservation)
        }
        startActivity(intent)

        val mapbutton:Button = findViewById(R.id.return_to_Map)
        mapbutton.setOnClickListener {
            // Create an intent to start the MapActivity
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent) // Start the new activity
        }

        // Optionally, clear the fields after saving
        birdNameEditText.text.clear()
        birdSpeciesEditText.text.clear()
        observationDetailsEditText.text.clear()
        capturedImageView.setImageResource(0) // Clear the captured image
    }
}




