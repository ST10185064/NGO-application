package com.example.myapplication
import java.io.Serializable

data class SavedObservation(
    val name: String,
    val birdSpecies: String,
    val distance: String,
    val date: String,
    val notes: String
) : Serializable

