package com.example.myapplication

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class ObservationListActivity : AppCompatActivity() {
    private lateinit var recyclerView: RecyclerView
    private lateinit var observationAdapter: ObservationAdapter
    private val savedObservations = mutableListOf<SavedObservation>()

    private lateinit var birdNameTextView: TextView
    private lateinit var observationDateTextView: TextView
    private lateinit var locationTextView: TextView
    private lateinit var notesTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_observation_lis)

        recyclerView = findViewById(R.id.observationsRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        birdNameTextView = findViewById(R.id.birdNameTextView)
        observationDateTextView = findViewById(R.id.observationDateTextView)
        locationTextView = findViewById(R.id.locationTextView)
        notesTextView = findViewById(R.id.notesTextView)

        val savedObservation = intent.getSerializableExtra("SAVED_OBSERVATION") as? SavedObservation

        // Prepopulate the list with some dummy observations if it's empty
        if (savedObservations.isEmpty()) {
            savedObservations.add(SavedObservation("Observation 1", "First bird species", "2km", "01/10/2024", "Park notes"))
            savedObservations.add(SavedObservation("Observation 2", "Second bird species", "3km", "02/10/2024", "Beach notes"))
            savedObservations.add(SavedObservation("Observation 3", "Third bird species", "1km", "03/10/2024", "Forest notes"))
        }

        // If a saved observation is passed from another activity, add it
        if (savedObservation != null) {
            savedObservations.add(savedObservation)
            updateObservationDetails(savedObservation) // Display it
        }

        // Set up the adapter with both click listeners
        observationAdapter = ObservationAdapter(savedObservations,
            onDistanceClick = { clickedObservation ->
                // Handle distance button click (could show a map or do something specific)
            },
            onItemClick = { clickedObservation ->
                // Display the clicked observation's details in the text views
                updateObservationDetails(clickedObservation)
            }
        )

        recyclerView.adapter = observationAdapter

        // Handle the FloatingActionButton click
        val addObservationFab: FloatingActionButton = findViewById(R.id.addObservationFab)
        addObservationFab.setOnClickListener {
            // Start another activity to add an observation, e.g., MapsActivity
        }
    }

    // Method to update the details view with the clicked observation
    private fun updateObservationDetails(observation: SavedObservation) {
        birdNameTextView.text = observation.name
        observationDateTextView.text = "Date: ${observation.date}"
        locationTextView.text = "Location: ${observation.distance}"
        notesTextView.text = "Notes: ${observation.notes}"
    }
}
