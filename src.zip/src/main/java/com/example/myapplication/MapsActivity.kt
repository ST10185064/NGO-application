package com.example.myapplication

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.gms.maps.model.Polyline
import com.google.android.gms.maps.model.PolylineOptions
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStream
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import android.location.Location
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.*
import com.google.android.gms.tasks.Task
import java.io.*



import android.location.Geocoder


class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private var isRouteMode = false
    private lateinit var map: GoogleMap
    private var userLatLng: LatLng? = null // Store user's location
    private var lastClickedMarker: Marker? = null // To track the last clicked marker
    private val markerList = mutableListOf<Marker>() // List to hold all markers
    private var polyline: Polyline? = null // To store and display polyline
    private val LOCATION_PERMISSION_REQUEST_CODE = 1
    private val apiKey = "ueol3cpefg0u"  // Replace with your eBird API Key
    private val GapiKey = "AIzaSyDaf--F-rVZpwAoBigBn0_NavpT5Uo0TTA"  // Replace with your Google Maps API Key for Directions
    private lateinit var userMarker: Marker // Track the user location marker

    private val defaultLocation = "239 Pretorius St, Pretoria Central, Pretoria, 0126"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_maps)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap

        map.uiSettings.isZoomControlsEnabled = true

        // Set custom user location
        setCustomUserLocation(defaultLocation)

        // Set up the marker click listener
        map.setOnMarkerClickListener { marker ->
            handleMarkerClick(marker)
            true
        }

        map.setOnMapClickListener {
            if (isRouteMode) {
                exitRouteMode()
            }
        }

        // Display hotspots
        fetchAndDisplayHotspots()
    }

    private fun setCustomUserLocation(address: String) {
        val geocoder = Geocoder(this)
        try {
            val addressList = geocoder.getFromLocationName(address, 1)
            if (addressList != null && addressList.isNotEmpty()) {
                val location = addressList[0]
                userLatLng = LatLng(location.latitude, location.longitude)

                // Remove existing user marker if it exists
                if (::userMarker.isInitialized) {
                    userMarker.remove()
                }

                // Add new user marker
                userMarker = map.addMarker(
                    MarkerOptions()
                        .position(userLatLng!!)
                        .title("You are here")
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
                )!!

                // Move camera to the user location
                map.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng!!, 15f))

                // Fetch and display hotspots after setting location
                fetchAndDisplayHotspots()
            } else {
                Toast.makeText(this, "Unable to find the specified address.", Toast.LENGTH_SHORT).show()
            }
        } catch (e: IOException) {
            e.printStackTrace()
            Toast.makeText(this, "Error setting custom location.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun handleMarkerClick(marker: Marker) {
        if (!isRouteMode) {
            // Enter route mode
            isRouteMode = true
            hideOtherMarkers(marker)
            val destinationLatLng = marker.position // Hotspot location
            drawRouteToMarker(destinationLatLng)
        } else {
            // Already in route mode, open observation activity
            openObservationActivity(marker)
        }
    }

    private fun calculateDistance(startLatLng: LatLng, endLatLng: LatLng): Float {
        val results = FloatArray(1)
        Location.distanceBetween(
            startLatLng.latitude, startLatLng.longitude,
            endLatLng.latitude, endLatLng.longitude,
            results
        )
        return results[0] // Distance in meters
    }

    private fun hideOtherMarkers(selectedMarker: Marker) {
        for (marker in markerList) {
            // Hide all markers except for the selected marker and user marker
            if (marker != selectedMarker && marker != userMarker) {
                marker.isVisible = false
            }
        }
    }

    // This function remains unchanged
    private fun showAllMarkers() {
        for (marker in markerList) {
            marker.isVisible = true
        }
        userMarker.isVisible = true // Ensure the user location marker is visible
    }

    private fun exitRouteMode() {
        isRouteMode = false
        showAllMarkers() // Show all markers when exiting route mode
        polyline?.remove()
        polyline = null
    }

    private fun openObservationActivity(marker: Marker) {
        val hotspotName = marker.tag as String?
        if (userLatLng != null) {
            val destinationLatLng = marker.position
            val distance = calculateDistance(userLatLng!!, destinationLatLng) // Calculate distance in meters

            getHotspotIdByName(hotspotName) { hotspotId ->
                if (hotspotId != null) {
                    val intent = Intent(this, ObservationActivity::class.java)
                    intent.putExtra("HOTSPOT_NAME", hotspotName)
                    intent.putExtra("DISTANCE", distance)
                    startActivity(intent)
                } else {
                    Toast.makeText(
                        this,
                        "Hotspot ID not found for $hotspotName",
                        Toast.LENGTH_SHORT
                    )
                        .show()
                }
            }
        }
    }

    private fun getHotspotIdByName(hotspotName: String?, callback: (String?) -> Unit) {
        if (hotspotName == null) {
            callback(null)
            return
        }

        val url = "https://api.ebird.org/v2/ref/hotspot/ZA?fmt=json"
        val client = OkHttpClient()
        val request = Request.Builder()
            .url(url)
            .addHeader("X-eBirdApiToken", apiKey)
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                e.printStackTrace()
                callback(null)
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                if (response.isSuccessful) {
                    val jsonData = response.body?.string()
                    if (!jsonData.isNullOrEmpty()) {
                        val hotspots = JSONArray(jsonData)
                        for (i in 0 until hotspots.length()) {
                            val hotspot = hotspots.getJSONObject(i)
                            val locName = hotspot.getString("locName")
                            if (locName == hotspotName) {
                                val locId = hotspot.getString("locId")
                                callback(locId)
                                return
                            }
                        }
                    }
                }
                callback(null)
            }
        })
    }

    private fun drawRouteToMarker(destinationLatLng: LatLng) {
        if (userLatLng != null) {
            drawRoute(userLatLng!!, destinationLatLng)
        } else {
            Toast.makeText(this, "User location not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun drawRoute(origin: LatLng, destination: LatLng) {
        val directionsUrl = getDirectionsUrl(origin, destination)
        FetchRouteTask().execute(directionsUrl)
    }

    private fun getDirectionsUrl(origin: LatLng, dest: LatLng): String {
        return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin.latitude},${origin.longitude}&destination=${dest.latitude},${dest.longitude}&key=$GapiKey"
    }

    private inner class FetchRouteTask : AsyncTask<String, Void, String>() {
        override fun doInBackground(vararg url: String?): String {
            return try {
                downloadUrl(url[0]!!)
            } catch (e: Exception) {
                e.printStackTrace()
                ""
            }
        }

        override fun onPostExecute(result: String?) {
            super.onPostExecute(result)
            val parserTask = ParserTask()
            parserTask.execute(result)
        }
    }

    private inner class ParserTask : AsyncTask<String, Int, List<List<HashMap<String, String>>>>() {
        override fun doInBackground(vararg jsonData: String?): List<List<HashMap<String, String>>> {
            val jsonObject = JSONObject(jsonData[0])
            val parser = DirectionsJSONParser()
            return parser.parse(jsonObject)
        }

        override fun onPostExecute(result: List<List<HashMap<String, String>>>) {
            val points = ArrayList<LatLng>()
            val lineOptions = PolylineOptions()

            for (i in result.indices) {
                val path = result[i]
                for (j in path.indices) {
                    val point = path[j]
                    val lat = point["lat"]!!.toDouble()
                    val lng = point["lng"]!!.toDouble()
                    val position = LatLng(lat, lng)
                    points.add(position)
                }
            }

            lineOptions.addAll(points)
            lineOptions.width(10f)
            lineOptions.color(Color.RED)

            polyline?.remove()
            polyline = map.addPolyline(lineOptions)
        }
    }

    private fun downloadUrl(strUrl: String): String {
        var data = ""
        var iStream: InputStream? = null
        var urlConnection: HttpURLConnection? = null
        try {
            val url = URL(strUrl)
            urlConnection = url.openConnection() as HttpURLConnection
            urlConnection.connect()

            iStream = urlConnection.inputStream
            val br = BufferedReader(InputStreamReader(iStream))
            val sb = StringBuilder()
            var line: String?

            while (br.readLine().also { line = it } != null) {
                sb.append(line)
            }

            data = sb.toString()
            br.close()
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            iStream?.close()
            urlConnection?.disconnect()
        }
        return data
    }

    private fun fetchAndDisplayHotspots() {
        val url = "https://api.ebird.org/v2/ref/hotspot/ZA?fmt=json"
        val client = OkHttpClient()
        val request = Request.Builder()
            .url(url)
            .addHeader("X-eBirdApiToken", apiKey)
            .build()

        client.newCall(request).enqueue(object : okhttp3.Callback {
            override fun onFailure(call: okhttp3.Call, e: IOException) {
                e.printStackTrace()
                runOnUiThread {
                    Toast.makeText(this@MapsActivity, "Failed to load hotspots.", Toast.LENGTH_SHORT)
                        .show()
                }
            }

            override fun onResponse(call: okhttp3.Call, response: okhttp3.Response) {
                if (response.isSuccessful) {
                    val jsonData = response.body?.string()
                    if (!jsonData.isNullOrEmpty()) {
                        runOnUiThread {
                            addHotspotMarkers(jsonData)
                        }
                    }
                }
            }
        })
    }

    private fun addHotspotMarkers(jsonData: String) {
        try {
            val hotspots = JSONArray(jsonData)
            for (i in 0 until hotspots.length()) {
                val hotspot = hotspots.getJSONObject(i)
                val locName = hotspot.getString("locName")
                val lat = hotspot.getDouble("lat")
                val lng = hotspot.getDouble("lng")
                val position = LatLng(lat, lng)

                // Add a marker for the hotspot
                val marker = map.addMarker(
                    MarkerOptions()
                        .position(position)
                        .title(locName)
                )

                // Store the locName in marker's tag for reference later
                marker?.tag = locName

                // Add the marker to the list of markers
                marker?.let { markerList.add(it) }
            }
        } catch (e: JSONException) {
            e.printStackTrace()
            Toast.makeText(this, "Failed to parse hotspots.", Toast.LENGTH_SHORT).show()
        }
    }
}
