package com.example.myapplication

import android.content.Intent
import android.graphics.Color
import android.location.Geocoder
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.google.maps.android.PolyUtil
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.Locale

class SettingsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var metricSwitch: Switch
    private lateinit var maxDistanceEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var geocoder: Geocoder
    private lateinit var googleMap: GoogleMap
    private var selectedHotspot: Marker? = null
    private var isRouteDrawn = false

    private val defaultLocationAddress = "239 Pretorius St, Pretoria Central, Pretoria, 0126"
    private var defaultLocationLatLng: LatLng? = null

    private val coroutineScope = CoroutineScope(Dispatchers.Main + Job())

    private var hotspotMarkers: List<Marker> = listOf()
    private var routePolyline: Polyline? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        metricSwitch = findViewById(R.id.metric_switch)
        maxDistanceEditText = findViewById(R.id.max_distance_edit_text)
        saveButton = findViewById(R.id.save_button)

        geocoder = Geocoder(this, Locale.getDefault())

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        saveButton.setOnClickListener {
            fetchHotspotsForDefaultLocation()
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map

        googleMap.uiSettings.isZoomControlsEnabled = true
        coroutineScope.launch {
            defaultLocationLatLng = getDefaultLocationLatLng()
            defaultLocationLatLng?.let {
                addDefaultLocationMarker(it)
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(it, 10f))
            }
        }

        googleMap.setOnMarkerClickListener { marker ->

            if (marker.tag == "hotspot") {
                if (selectedHotspot == marker && isRouteDrawn) {
                    // This is the second click on the same hotspot
                    val intent = Intent(this, ObservationActivity::class.java)
                    intent.putExtra("HOTSPOT_NAME", marker.title)
                    startActivity(intent)
                } else {
                    coroutineScope.launch {
                        defaultLocationLatLng?.let { defaultLocation ->
                            clearHotspotsExcept(marker)
                            drawRoute(defaultLocation, marker.position)
                            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(marker.position, 15f))
                            selectedHotspot = marker
                            isRouteDrawn = true
                        }
                    }
                }
            } else {
                // Reset selection if a non-hotspot marker is clicked
                selectedHotspot = null
                isRouteDrawn = false
            }
            true
        }
    }

    private fun addDefaultLocationMarker(location: LatLng) {
        googleMap.addMarker(
            MarkerOptions()
                .position(location)
                .title("Default Location")
                .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))
        )
    }

    private fun fetchHotspotsForDefaultLocation() {
        coroutineScope.launch {
            val defaultLocation = getDefaultLocationLatLng()
            if (defaultLocation != null) {
                val distance = maxDistanceEditText.text.toString().toDoubleOrNull() ?: 10.0
                val useMetric = metricSwitch.isChecked
                val convertedDistance = if (useMetric) distance else distance * 1.60934
                fetchHotspots(defaultLocation.latitude, defaultLocation.longitude, convertedDistance)
            } else {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@SettingsActivity, "Failed to find default location", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private suspend fun getDefaultLocationLatLng(): LatLng? = withContext(Dispatchers.IO) {
        try {
            val addresses = geocoder.getFromLocationName(defaultLocationAddress, 1)
            if (addresses != null && addresses.isNotEmpty()) {
                val location = addresses[0]
                LatLng(location.latitude, location.longitude)
            } else {
                null
            }
        } catch (e: IOException) {
            e.printStackTrace()
            null
        }
    }

    private suspend fun fetchHotspots(latitude: Double, longitude: Double, distance: Double) = withContext(Dispatchers.IO) {
        val url = "https://api.ebird.org/v2/ref/hotspot/geo?lat=$latitude&lng=$longitude&dist=$distance&fmt=json&region=ZA"

        val client = OkHttpClient()
        val EBIRD_API_KEY = "ueol3cpefg0u" // Replace with your actual API key
        val request = Request.Builder()
            .url(url)
            .addHeader("X-eBirdApiToken", EBIRD_API_KEY)
            .build()

        try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val hotspotsJson = response.body?.string()
                withContext(Dispatchers.Main) {
                    hotspotsJson?.let { displayHotspotsOnMap(it, LatLng(latitude, longitude)) }
                }
            } else {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@SettingsActivity, "Failed to fetch hotspots", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: IOException) {
            withContext(Dispatchers.Main) {
                Toast.makeText(this@SettingsActivity, "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun displayHotspotsOnMap(hotspotsJson: String, center: LatLng) {
        try {
            val hotspots = JSONArray(hotspotsJson)
            googleMap.clear() // Clear previous markers
            hotspotMarkers = mutableListOf()

            // Add the blue marker for the center (default location)
            defaultLocationLatLng?.let { addDefaultLocationMarker(it) }

            for (i in 0 until hotspots.length()) {
                val hotspot = hotspots.getJSONObject(i)
                val lat = hotspot.getDouble("lat")
                val lng = hotspot.getDouble("lng")
                val name = hotspot.getString("locName")

                val marker = googleMap.addMarker(
                    MarkerOptions()
                        .position(LatLng(lat, lng))
                        .title(name)
                        .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)) // Red marker for hotspots
                )
                marker?.tag = "hotspot"
                marker?.let { (hotspotMarkers as MutableList<Marker>).add(it) }
            }

            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(center, 10f))
            Toast.makeText(this, "Displaying ${hotspotMarkers.size} hotspots", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Error parsing hotspots: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun clearHotspotsExcept(selectedMarker: Marker) {
        hotspotMarkers.forEach { marker ->
            if (marker != selectedMarker) {
                marker.remove()
            }
        }
        hotspotMarkers = listOf(selectedMarker)
    }

    private suspend fun drawRoute(origin: LatLng, destination: LatLng) = withContext(Dispatchers.IO) {
        // Constructing the directions URL
        val url = "https://maps.googleapis.com/maps/api/directions/json?origin=${origin.latitude},${origin.longitude}&destination=${destination.latitude},${destination.longitude}&key=AIzaSyDaf--F-rVZpwAoBigBn0_NavpT5Uo0TTA"

        val client = OkHttpClient()
        val request = Request.Builder().url(url).build()

        try {
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val directionsJson = response.body?.string()
                withContext(Dispatchers.Main) {
                    directionsJson?.let {
                        // Logging the directions JSON to debug
                        println("Directions JSON: $it")

                        drawPolylineOnMap(it)
                    }
                }
            } else {
                withContext(Dispatchers.Main) {
                    Toast.makeText(this@SettingsActivity, "Failed to fetch directions", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: IOException) {
            withContext(Dispatchers.Main) {
                Toast.makeText(this@SettingsActivity, "Network error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun drawPolylineOnMap(directionsJson: String) {
        try {
            // Parsing the JSON response from the Directions API
            val jsonObject = JSONObject(directionsJson)
            val routes = jsonObject.getJSONArray("routes")

            if (routes.length() > 0) {
                val points = routes.getJSONObject(0)
                    .getJSONObject("overview_polyline")
                    .getString("points")

                // Decoding the polyline points
                val decodedPoints = PolyUtil.decode(points)
                routePolyline?.remove()

                // Adding the polyline to the map
                routePolyline = googleMap.addPolyline(
                    PolylineOptions()
                        .addAll(decodedPoints)
                        .color(Color.BLACK) // Use desired color for the route
                        .width(5f)          // Set the width of the polyline
                )

                Toast.makeText(this, "Route drawn successfully!", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "No route found", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error parsing directions: ${e.message}", Toast.LENGTH_SHORT).show()
            e.printStackTrace()
        }
    }

}
