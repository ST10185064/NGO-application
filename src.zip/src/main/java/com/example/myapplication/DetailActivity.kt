package com.example.myapplication
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val birdNameTextView: TextView = findViewById(R.id.birdNameTextView)
        val observationDateTextView: TextView = findViewById(R.id.observationDateTextView)
        val locationTextView: TextView = findViewById(R.id.locationTextView)
        val notesTextView: TextView = findViewById(R.id.notesTextView)

        // Get the observation detail from the intent
        val observation = intent.getSerializableExtra("OBSERVATION_DETAIL") as? SavedObservation

        // Update the UI with the observation data
        if (observation != null) {
            birdNameTextView.text = observation.name
            observationDateTextView.text = observation.birdSpecies
            locationTextView.text = observation.distance
            notesTextView.text = "Some additional notes for ${observation.notes}" // Modify as necessary
        }
    }
}
