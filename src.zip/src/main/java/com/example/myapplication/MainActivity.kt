package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val openMapButton: Button = findViewById(R.id.openMapButton)
        val settingbutton: Button = findViewById(R.id.settingbutton)

        // Set an OnClickListener for the button
        openMapButton.setOnClickListener {
            // Create an Intent to start MapsActivity
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)

        }

        settingbutton.setOnClickListener{
            val intent = Intent(this,SettingsActivity::class.java)
            startActivity(intent)
        }
    }
}